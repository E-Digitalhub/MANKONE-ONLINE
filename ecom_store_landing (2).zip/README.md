# Mankone Store Landing Page

This is a responsive landing page for promoting the **Mankone ECom Store**, allowing users to create high-converting eCommerce stores in just a few clicks.

## 🔥 Features
- Mobile-first responsive design
- Plug-n-play templates
- Email marketing and cart reminders
- Compatible with any payment gateway
- Custom domain ready (mankone.online)

## 🌐 Live Demo
[Visit GitHub Pages](https://your-username.github.io/mankone-store)

## 🛠️ How to Use
1. Clone or fork the repository
2. Edit the `index.html` or `index-with-nav.html`
3. Push changes to `main` branch
4. Enable GitHub Pages in the repo settings
5. (Optional) Add a custom domain in the CNAME file

---

**Powered by** [mankone.odoo.com](https://mankone.odoo.com)
